set(DRIVER_LIST bram;common;gpio;intc;tmrctr;uartns550)
